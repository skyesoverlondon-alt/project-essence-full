// Entry point for the Essence Crown engine.
// Real logic will live in other files under src/engine/.
export {};
